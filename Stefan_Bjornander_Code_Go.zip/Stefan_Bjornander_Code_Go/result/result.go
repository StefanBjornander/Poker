﻿package result

const (
  // Tie represent a `tie` scenario
  Tie = 0

  // Win represent a `win` scenario
  Win = 1

  // Lose represent a `lose` scenario
  Lose = 2
)