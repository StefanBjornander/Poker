﻿namespace Poker {
  enum Rank {Nothing, OnePair, TwoPairs, ThreeOfAKind, Straight,
             Flush, FullHouse, FourOfAKind, StraightFlush, RoyalFlush};
}
