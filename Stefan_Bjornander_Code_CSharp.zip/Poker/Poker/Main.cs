﻿using System;

namespace Poker {
  class Start {
    static void Main(string[] args) {
      try {
        Console.Out.WriteLine(new Hand("Th Jh Qh Kh Ah")); // Royal Flush
        Console.Out.WriteLine(new Hand("Ts Js Qs 9s 8s")); // Straight Flush
        Console.Out.WriteLine(new Hand("Ts Tc Td 9s Th")); // Four of a kind
        Console.Out.WriteLine(new Hand("5s 8h 5c 8s 5d")); // Full House
        Console.Out.WriteLine(new Hand("Kd 8d 4d Td 2d")); // Flush
        Console.Out.WriteLine(new Hand("5s 8h 4c 6s 7d")); // Straight
        Console.Out.WriteLine(new Hand("5s 7h 4c 7s 7d")); // Three of a kind
        Console.Out.WriteLine(new Hand("5s 6h 4c 6s 5d")); // Two Pairs
        Console.Out.WriteLine(new Hand("5s 7h 4c 7s 8d")); // One Pair
        Console.Out.Write(new Hand("2s 7h 4c Ts Qd"));     // Nothing
      }
      catch (PokerException pokerException) {
        Console.Out.WriteLine(pokerException.Message);
      }
    }
  }
}
