﻿using System;

namespace Poker {
  public class PokerException : ApplicationException  {
    public PokerException(string message)
     :base(message) {
    }
  }

  public class InvalidNumberOfCards : PokerException {
    public InvalidNumberOfCards(int number)
     :base("Invalid number of cards: " + number.ToString() + ".") {
    }
  }

  public class InvalidLengthOfCardText : PokerException {
    public InvalidLengthOfCardText(string cardText)
     :base("Invalid length of card text: " + cardText + ".") {
    }
  }

  public class InvalidCardValue : PokerException {
    public InvalidCardValue(char valueChar)
     :base("Invalid card value: " + valueChar + ".") {
    }
  }

  public class InvalidCardSuit : PokerException {
    public InvalidCardSuit(char suitChar)
     :base("Invalid card suit: " + suitChar + ".") {
    }
  }

  public class CardOccoursTwice : PokerException {
    public CardOccoursTwice(Card card)
     :base("Card occours twice in the hand: " + card.ToString() + ".") {
    }
  }

  public class HandsOverlaps : PokerException {
    public HandsOverlaps(Card card)
     :base("The same card occours in both hands: " +
           card.ToString() + ".") {
    }
  }
}