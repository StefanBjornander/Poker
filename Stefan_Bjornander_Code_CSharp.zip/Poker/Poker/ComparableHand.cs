﻿namespace Poker {
  public interface ComparableHand {
    Result CompareWith(ComparableHand compareTo);
  }
}
