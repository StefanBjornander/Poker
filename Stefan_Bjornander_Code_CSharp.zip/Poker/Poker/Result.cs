﻿namespace Poker {
  public enum Result {Tie, Win, Lose}
}
