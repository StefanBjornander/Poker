﻿using System;
using System.Collections.Generic;

namespace Poker {
  public class Card {
    private int m_value;
    private Suit m_suit;

    public Card(int value, Suit suit) {
      m_value = value;
      m_suit = suit;
    }

    public int Value {
      get {return m_value;}
    }

    public Suit Suit {
      get {return m_suit;}
    }

    private static string[] m_valueArray = 
      {"Two", "Three", "Four", "Five", "Six", "Seven",
       "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};

    public override string ToString() {
      return m_valueArray[m_value - 2] + " of " +
             Enum.GetName(typeof(Suit), m_suit);
    }

    public override bool Equals(object obj) {
      if (obj is Card) {
        Card card = (Card) obj;
        return (m_value == card.m_value) &&
               (m_suit == card.m_suit);
      }

      return false;
    }

    public override int GetHashCode() {
      return base.GetHashCode();
    }
  }

  public class HighestFirst : IComparer<Card> {
    public int Compare(Card leftCard, Card rightCard) {
      return rightCard.Value - leftCard.Value;
    }
  }
  
  public class LowestFirst : IComparer<Card> {
    public int Compare(Card leftCard, Card rightCard) {
      return leftCard.Value - rightCard.Value;
    }
  }
}