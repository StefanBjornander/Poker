﻿namespace Poker {
  enum Value {Jack = 11, Queen, King, Ace};
}