﻿using System.Text;
using System.Linq;
using System.Collections.Generic;

namespace Poker {
  public class Hand : ComparableHand {
    private List<string> m_rankTextList = new List<string>()
            {"Nothing", "One Pair", "Two Pairs", "Three Of A Kind",
             "Straight", "Flush", "Full House", "Four Of A Kind",
             "Straight Flush", "Royal Flush"};

    private List<Card> m_cards;
    private Rank m_rank;
    private int m_maxValue = 0, m_minValue = 0;
    private List<int> m_restValues;
    private IDictionary<int, List<int>> m_map;

    public Hand(string text) {
      m_cards = TextToCards(text);
      m_cards.Sort(new HighestFirst());
      ExtractSameOfAKind();
      SetRankOfHand();
    }

    private static List<Card> TextToCards(string handText) {
      string[] cardTextArray = handText.Split(' ');

      if (cardTextArray.Length != 5) {
        throw (new InvalidNumberOfCards(cardTextArray.Length));
      }

      List<Card> cardList = new List<Card>();
      foreach (string cardText in cardTextArray) {
        if (cardText.Length != 2) {
          throw (new InvalidLengthOfCardText(cardText));
        }

        char valueChar = cardText[0];
        char valueCharUpper = char.ToUpper(valueChar);
        const string valueText = "23456789TJQKA";
        int value;

        if (valueText.Contains(valueCharUpper)) {
          value = valueText.IndexOf(valueCharUpper) + 2;
        }
        else {
          throw (new InvalidCardValue(valueChar));
        }

        char suitChar = cardText[1];
        char suitCharUpper = char.ToUpper(suitChar);
        IDictionary<char, Suit> suitMap = new Dictionary<char, Suit>()
          {{'S', Suit.Spades}, {'H', Suit.Hearts}, 
           {'D', Suit.Diamonds}, {'C', Suit.Clubs}};
        Suit suit;

        if (suitMap.ContainsKey(suitCharUpper)) {
          suit = suitMap[suitCharUpper];
        }
        else {
          throw (new InvalidCardSuit(cardText[1]));
        }

        Card card = new Card(value, suit);
        if (cardList.Contains(card)) {
          throw (new CardOccoursTwice(card));
        }

        cardList.Add(card);
      }

      return cardList;
    }

    private void SetRankOfHand() {
      if (IsRoyalFlush()) {
        m_rank = Rank.RoyalFlush;
      }
      else if (IsStraightFlush()) {
        m_rank = Rank.StraightFlush;
        m_maxValue = m_cards.First().Value;
      }
      else if (IsFourOfAKind()) {
        m_rank = Rank.FourOfAKind;
        m_maxValue = m_map[4].First();
      }
      else if (IsFullHouse()) {
        m_rank = Rank.FullHouse;
        m_maxValue = m_map[3].First();
      }
      else if (IsFlush()) {
        m_rank = Rank.Flush;
        m_restValues = new List<int>();

        foreach (Card card in m_cards) {
          m_restValues.Add(card.Value);
        }
      }
      else if (IsStraight()) {
        m_rank = Rank.Straight;
        m_maxValue = m_cards.First().Value;
      }
      else if (IsThreeOfAKind()) {
        m_rank = Rank.ThreeOfAKind;
        m_maxValue = m_map[3].First();
      }
      else if (IsTwoPairs()) {
        m_rank = Rank.TwoPairs;
        m_maxValue = m_map[2].First();
        m_minValue = m_map[2].Last();
        m_restValues = m_map[1];
      }
      else if (IsOnePair()) {
        m_rank = Rank.OnePair;
        m_maxValue = m_map[2].First();
        m_restValues = m_map[1];
      }
      else {
        m_rank = Rank.Nothing;
        m_restValues = new List<int>();

        foreach (Card card in m_cards) {
          m_restValues.Add(card.Value);
        }
      }
    }

    private bool IsRoyalFlush() {
      return IsStraightFlush() &&
             (m_cards.First().Value == ((int) Value.Ace));
    }

    private bool IsStraightFlush() {
      return IsStraight() && IsFlush();
    }

    private bool IsFourOfAKind() {
      return m_map.Keys.Contains(4);
    }

    private bool IsFullHouse() {
      return IsThreeOfAKind() && IsOnePair();
    }

    private bool IsFlush() {
      Suit firstSuit = m_cards[0].Suit;      
      return (m_cards.FindAll
              (card => card.Suit == firstSuit).Count == m_cards.Count);
    }

    private bool IsStraight() {
      return (m_map.Keys.Count == 1) && m_map.Keys.Contains(1) &&
             (m_cards.First().Value == (m_cards.Last().Value + 4));
    }

    private bool IsThreeOfAKind() {
      return m_map.Keys.Contains(3);
    }

    private bool IsTwoPairs() {
      return m_map.Keys.Contains(2) && (m_map[2].Count == 2);
    }

    private bool IsOnePair() {
      return m_map.Keys.Contains(2);
    }

    private void ExtractSameOfAKind() {
      m_map = new Dictionary<int,List<int>>();

      foreach (Card outerCard in m_cards) {
        int count = 0;
  
        foreach (Card innerCard in m_cards) {
          if (outerCard.Value == innerCard.Value) {
            ++count;
          }
        }

        if (!m_map.ContainsKey(count)) {
          m_map[count] = new List<int>();
        }

        if (!m_map[count].Contains(outerCard.Value)) {
          m_map[count].Add(outerCard.Value);
        }
      }
    }

    public Result CompareWith(ComparableHand comparableHand) {
      int compare = 0;

      if (comparableHand is Hand) {
        Hand hand = (Hand) comparableHand;

        foreach (Card card in m_cards) {
          if (hand.m_cards.Contains(card)) {
            throw (new HandsOverlaps(card));
          }
        }

        if (m_rank != hand.m_rank) {
          compare = m_rank - hand.m_rank;
        }
        else if (m_maxValue != hand.m_maxValue) {
          compare = m_maxValue - hand.m_maxValue;
        }
        else if (m_minValue != hand.m_minValue) {
          compare = m_minValue - hand.m_minValue;
        }
        else {
          for (int index = 0; index < m_restValues.Count; ++index) {
            if (m_restValues[index] != hand.m_restValues[index]) {
              compare = m_restValues[index] - hand.m_restValues[index];
              break;
            }
          }
        }
      }

      if (compare > 0) {
        return Result.Win;
      }
      else if (compare < 0) {
        return Result.Lose;
      }
      else {
        return Result.Tie;
      }
    }
    public override string ToString() {
      StringBuilder buffer = new StringBuilder("{");
      bool first = true;

      foreach (Card card in m_cards) {
        buffer.Append((first ? "" : ", ") + card.ToString());
        first = false;
      }

      buffer.Append("}\n" + m_rankTextList[(int) m_rank]);

      if (m_maxValue != 0) {
        buffer.Append(", max value " + m_maxValue);
      }

      if (m_minValue != 0) {
        buffer.Append(", min value " + m_minValue);
      }

      buffer.Append(", {");
      bool firstList = true;
      foreach (KeyValuePair<int,List<int>> entry in m_map) {
        buffer.Append((firstList ? "" : ", ") + entry.Key + ": [");

        bool firstValue = true;
        foreach (int value in entry.Value) {
          buffer.Append((firstValue ? "" : ", ") + value.ToString());
          firstValue = false;
        }

        firstList = false;
        buffer.Append("]");
      }

      return buffer.ToString() + "}\n";
    }
  }
}